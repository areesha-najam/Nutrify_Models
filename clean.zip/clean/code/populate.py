
from doctest import IGNORE_EXCEPTION_DETAIL
import pandas as pd
import numpy as np
# df1 = pd.read_csv("populate_data\sample.csv")
# df2 = pd.read_csv("populate_data\sormatted_unique_ingTensor.csv")
# SAMPLE FILES
df1 = pd.read_csv("sample_cleaned_ingrams.csv")
df2 = pd.read_csv("sormatted_unique_ingTensor.csv")
# print(df2.columns[3:])
r=[]
for x in range(len(df2.columns)):
    r.append(np.nan)
s2 = pd.Series(r, index=df2.columns)
# for i in range(len(df1)):
#     df2 = df2.append(s2, ignore_index = True)
d = {}
outerloop = 0
written_row = 0
for index1,row1 in df1.iterrows():
    # if outerloop > 20011: #got 1425 recipies
    if outerloop > 50031: #Time taken 9:49 to 9:58
        break
    '''   adding empty row '''
    df2 = df2.append(s2, ignore_index = True)
    row_index = 1
    for col in df2.columns[3:]:
        if row1["ingredient_name"] == col:
            if row1["Recipe_title_x"] not in d.keys():
                # print("in")
                df2[col][written_row] = row1["quantity"]
                df2["Recipe_id"][written_row] = row1["Recipe_id"]
                df2["Recipe_title_x"][written_row] = row1["Recipe_title_x"]
                df2["Serving_size"][written_row] = row1["Servings"]
                ''' mainataining a dictionary incase I want to revist to same recipe for some other ing'''
                d[row1["Recipe_title_x"]] = written_row
                print(outerloop)
                written_row+=1

            else:
                df2[col][d[row1["Recipe_title_x"]]]  = row1["quantity"]
                print(outerloop)

        else:
            row_index+=1
    outerloop += 1
df2.to_csv("Populatedfile50K_inGRAMS.csv", index = False)
print(outerloop)


        



