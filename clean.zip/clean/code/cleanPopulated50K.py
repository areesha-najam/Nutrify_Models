import pandas as pd
import numpy as np

#  convert fraction and mixed fractions to float

from fractions import Fraction
def number_str_to_float(amount_str):
    number_as_float = amount_str
    try:
        number_as_float = round(float(sum(Fraction(s)
                                for s in f"{amount_str}".split())), 2)
    except:
        print(f'\'{number_as_float}\' is not a number or fraction')
        return(np.NaN)
    if isinstance(number_as_float, float):
        return(number_as_float)


df1 = pd.read_csv("Final_Populated50K.csv", low_memory= False)
print(len(df1.columns))
# drop empty columns
df1.dropna(how='all', axis=1, inplace=True)
#  convert fraction to float
for index1,row1 in df1.iterrows():
  for i in range(len(row1)):
    if type(row1[i]) == str and "/" in row1[i]:
      a =  number_str_to_float(row1[i])
      df1.replace(row1[i], a)
  
df1 = df1.replace("For", np.NaN)
df1 = df1.fillna(0)

print(len(df1.columns))
df1.to_csv("Final_Populated50K_cleaned.csv")

    
    
