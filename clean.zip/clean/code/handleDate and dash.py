import datetime
# date = "1-Mar"
# # month_name = date[date.find("-")+1 :]
# # print(month_name)
# datetime_object = datetime.datetime.strptime(month_name, "%b")
# month_number = datetime_object.month
# print(month_number)
# # final = str(month_number) + "/" + date[:date.find("-")]
# # print(final)
# if "-" in date:
#     month_name = date[date.find("-")+1 :]
#     month_number = datetime.datetime.strptime(month_name, "%b").month
#     # month_number = datetime_object.month
#     final = str(month_number) + "/" + date[:date.find("-")]
#     print("kkkkkkkkkkkkkkkk", final)

import pandas as pd
import numpy as np

def handle_date (date):
    month_name = date[date.find("-")+1 :]
    month_number = datetime.datetime.strptime(month_name, "%b").month
    rest = date[:date.find("-")]
    if rest[0] =="0":
        rest = rest[1:]
    final = str(month_number) + "/" + rest
    return final 


def main():
    df1 = pd.read_csv("sample.csv")
    for i in range(len(df1['quantity'])):
        if "-" in str(df1['quantity'][i]):
            months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            if any(m in str(df1['quantity'][i]) for m in months):
                final = handle_date(df1['quantity'][i])

                df1['quantity'][i] = final
            else:
                a = df1['quantity'][i].find("-")
                df1['quantity'][i] = df1['quantity'][i][a+1:]
        else:
            pass
    df1.to_csv("sample_cleaned.csv", index = False)

main()
